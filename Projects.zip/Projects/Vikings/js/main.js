$(function(){

$('.heroes__item').slick({
  prevArrow:'<button type="button" class="slick-prev"><img src="images/l.png" alt=""></button>',
  nextArrow:'<button type="button" class="slick-next"><img src="images/r.png" alt=""></button>'
});

});
